import SwiftUI
import UIKit
import UniformTypeIdentifiers

private enum PatchPackagePickerPolicy {
    static let packageType = UTType(filenameExtension: "3105") ?? .data
    static let allowedContentTypes: [UTType] = [packageType, .data]
    static let copiesSelectedDocument = true
}

enum PatchGameMode: String {
    case normal
    case max

    var displayName: String { self == .normal ? "FREE FIRE NORMAL" : "FREE FIRE MAX" }
}

struct PatchProjectsView: View {
    let ghostTheme: Bool
    let gameMode: PatchGameMode
    var onBack: (() -> Void)? = nil
    @Environment(\.appLanguage) private var language
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @EnvironmentObject private var draftCoordinator: PatchDraftCoordinator
    @StateObject private var store = PatchProjectStore()
    @EnvironmentObject private var pantherSession: PantherSession
    @State private var countdownNow = Date()
    private let countdownTimer = Timer.publish(every: 1.0, on: .main, in: .common).autoconnect()
    private var keyCountdown: String {
        if pantherSession.permanent { return "Acceso permanente" }
        guard let expires = pantherSession.expiresAt else { return "Verificando key..." }
        let remaining = max(0, expires.timeIntervalSince(countdownNow))
        let total = Int(remaining)
        let days = total / 86400
        let hours = (total % 86400) / 3600
        let minutes = (total % 3600) / 60
        let secs = total % 60
        return String(format: "%dd %02dh %02dm %02ds", days, hours, minutes, secs)
    }
    @State private var showCreate = false
    @State private var showImporter = false
    @State private var searchText = ""
    @State private var busyPatchIDs: Set<UUID> = []
    @State private var patchActionMessage: String?
    @State private var patchRefreshToken = 0
    @State private var selectedPatchCategory = "AIMBOT"
    @State private var normalToggleStates: Set<String> = []
    @AppStorage("sensi.theme.color") private var themeName = "cyan"
    @State private var showThemePicker = false
    @State private var showOpenGameConfirm = false

    private var accent: Color {
        switch themeName {
        case "rojo": return Color(red: 0.95, green: 0.18, blue: 0.22)
        case "rosa": return Color(red: 1.0, green: 0.35, blue: 0.65)
        case "morado": return Color(red: 0.72, green: 0.28, blue: 0.95)
        case "verde": return Color(red: 0.15, green: 0.85, blue: 0.40)
        case "amarillo": return Color(red: 1.0, green: 0.85, blue: 0.1)
        case "rainbow", "raimbo":
            // Ciclo rojo → morado → amarillo → rosa → azul fuerte
            let phase = countdownNow.timeIntervalSinceReferenceDate.truncatingRemainder(dividingBy: 6.0) / 6.0
            return Color(hue: phase, saturation: 0.95, brightness: 1.0)
        default: return Color.cyan
        }
    }

    /// Gira el tono del fondo (ojos + energía) según el color elegido.
    private var themeHueDegrees: Double {
        switch themeName {
        case "rojo": return 0
        case "rosa": return -25
        case "morado": return -85
        case "verde": return 110
        case "amarillo": return 45
        case "rainbow", "raimbo":
            return (countdownNow.timeIntervalSinceReferenceDate * 40).truncatingRemainder(dividingBy: 360)
        default: return 160 // azul/cyan
        }
    }

    private var themeGlow: Color {
        accent.opacity(0.38)
    }

    @ViewBuilder
    private func themedBackgroundImage(_ name: String) -> some View {
        Image(name)
            .resizable()
            .scaledToFill()
            .hueRotation(.degrees(themeHueDegrees))
            .saturation(themeName == "rojo" ? 1.05 : 1.15)
            .overlay(
                LinearGradient(
                    colors: [themeGlow.opacity(0.15), accent.opacity(0.28), themeGlow.opacity(0.2)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .blendMode(.softLight)
            )
            .overlay(
                RadialGradient(
                    colors: [accent.opacity(0.45), accent.opacity(0.12), .clear],
                    center: UnitPoint(x: 0.5, y: 0.22),
                    startRadius: 10,
                    endRadius: 160
                )
                .blendMode(.plusLighter)
            )
    }

    /// Logo SENSI OG: el fondo rojo y el "OG" cambian de color; el blanco se mantiene.
    @ViewBuilder
    private func themedLogoImage() -> some View {
        Image("SensiOGMark")
            .resizable()
            .scaledToFill()
            .hueRotation(.degrees(themeHueDegrees))
            .saturation(themeName == "rojo" ? 1.0 : 1.2)
            .animation(.easeInOut(duration: 0.4), value: themeName)
    }

    // Orden fijo de arriba hacia abajo, independiente del estado de activación.
    private func avatarRank(_ name: String) -> Int {
        switch name.lowercased().trimmingCharacters(in: .whitespacesAndNewlines) {
        case "aim head", "head avatar": return 0
        case "cuello", "cuello avatar", "aim cuello": return 1
        case "pecho", "pecho avatar", "aim pecho": return 2
        case "aim drag", "sintura avatar", "aim sintura": return 3
        default: return 4
        }
    }

    private var orderedAvatarItems: [PatchLibraryItem] {
        store.items.filter { item in
            let name = item.project?.name ?? item.packageURL.deletingPathExtension().lastPathComponent
            return avatarRank(name) < 4
        }.sorted { left, right in
            let a = left.project?.name ?? left.packageURL.deletingPathExtension().lastPathComponent
            let b = right.project?.name ?? right.packageURL.deletingPathExtension().lastPathComponent
            if avatarRank(a) != avatarRank(b) { return avatarRank(a) < avatarRank(b) }
            return left.id.uuidString < right.id.uuidString
        }
    }

    private var orderedPublishedPatches: [PantherPatch] {
        pantherSession.publishedPatches.sorted { left, right in
            let a = avatarRank(left.name)
            let b = avatarRank(right.name)
            if a != b { return a < b }
            let nameOrder = left.name.localizedStandardCompare(right.name)
            if nameOrder != .orderedSame { return nameOrder == .orderedAscending }
            return left.id < right.id
        }
    }

    private var filteredItems: [PatchLibraryItem] {
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return store.items }
        return store.items.filter { item in
            if item.packageURL.lastPathComponent.localizedCaseInsensitiveContains(query) {
                return true
            }
            guard let project = item.project else { return false }
            return project.name.localizedCaseInsensitiveContains(query)
                || project.allBundleIdentifiers.contains {
                    $0.localizedCaseInsensitiveContains(query)
                }
                || project.directories.contains {
                    $0.relativePath.localizedCaseInsensitiveContains(query)
                }
                || project.rules.contains {
                    $0.relativePath.localizedCaseInsensitiveContains(query)
                        || $0.replacementFilename.localizedCaseInsensitiveContains(query)
                }
        }
    }

    init(ghostTheme: Bool = true, gameMode: PatchGameMode = .max, onBack: (() -> Void)? = nil) {
        self.ghostTheme = true // Pantalla neon para todas las entradas de Patches
        self.gameMode = gameMode
        self.onBack = onBack
#if targetEnvironment(simulator)
        _showCreate = State(
            initialValue: ProcessInfo.processInfo.arguments.contains("--simulate-patch-editor")
        )
#endif
    }

    var body: some View {
        NavigationStack {
            if ghostTheme {
                neonPatchScreen
                .ignoresSafeArea(.container, edges: .all)
            } else {
            VStack(spacing: 0) {
                AppSearchField(
                    text: $searchText,
                    prompt: language.text("patch.search"),
                    clearLabel: language.text("common.clear")
                )
                Divider()
                List {
                    if store.items.isEmpty && !store.isBusy {
                        emptyState
                            .listRowSeparator(.hidden)
                    } else if filteredItems.isEmpty && !store.isBusy {
                        searchEmptyState
                            .listRowSeparator(.hidden)
                    } else {
                        ForEach(filteredItems) { item in
                            itemRow(item)
                        }
                        .onDelete { offsets in
                            offsets.map { filteredItems[$0] }.forEach(store.delete)
                        }
                    }
                }
                .listStyle(.insetGrouped)
                .scrollContentBackground(ghostTheme ? .hidden : .visible)
                .background(ghostTheme ? Color.black.opacity(0.38) : Color.clear)
            }
            .background {
                if ghostTheme {
                    GeometryReader { geometry in
                        TimelineView(.animation(minimumInterval: 1.0 / 30.0)) { timeline in
                            let t = timeline.date.timeIntervalSinceReferenceDate
                            themedBackgroundImage("GhostPatchesBackground")
                                .frame(width: geometry.size.width * 1.12, height: geometry.size.height * 1.12)
                                .scaleEffect(1.04 + 0.02 * sin(t * 1.4))
                                .offset(x: 8 * sin(t * 1.1), y: 6 * cos(t * 0.9))
                                .frame(width: geometry.size.width, height: geometry.size.height)
                                .clipped()
                                .overlay(Color.black.opacity(0.28))
                                .animation(.easeInOut(duration: 0.45), value: themeName)
                        }
                    }
                    .ignoresSafeArea()
                }
            }
            .navigationTitle(language.text("patch.title"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button {
                            showCreate = true
                        } label: {
                            Label(language.text("patch.new"), systemImage: "doc.badge.plus")
                        }
                        Button {
                            showImporter = true
                        } label: {
                            Label(language.text("patch.import"), systemImage: "square.and.arrow.down")
                        }
                    } label: {
                        if store.isBusy {
                            ProgressView()
                        } else {
                            Image(systemName: "plus")
                        }
                    }
                    .disabled(store.isBusy)
                    .accessibilityLabel(language.text("patch.add"))
                }
            }
            .sheet(isPresented: $showImporter) {
                FileDocumentPicker(
                    allowedContentTypes: PatchPackagePickerPolicy.allowedContentTypes,
                    copiesSelectedDocument: PatchPackagePickerPolicy.copiesSelectedDocument,
                    allowsMultipleSelection: false,
                    onSelection: { result in
                        showImporter = false
                        if case .success(let urls) = result, let url = urls.first {
                            store.importPackage(at: url)
                        }
                    },
                    onCancel: {
                        showImporter = false
                    }
                )
                .ignoresSafeArea()
            }
            .sheet(isPresented: $showCreate) {
                PatchProjectEditorView(
                    existingProject: nil,
                    passwordIsProtected: false
                ) { project, password in
                    store.create(project: project, password: password)
                }
            }
            .sheet(item: $draftCoordinator.request) { request in
                PatchProjectEditorView(
                    existingProject: nil,
                    passwordIsProtected: false,
                    initialDraft: request.draft
                ) { project, password in
                    store.create(project: project, password: password)
                    draftCoordinator.clear()
                }
            }
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { _ in
                PatchUnlockView(store: store)
            }
            .alert(item: $store.alert) { alert in
                Alert(
                    title: Text(language.text(alert.titleKey)),
                    message: Text(alert.message(language: language)),
                    dismissButton: .default(Text(language.text("common.ok")))
                )
            }
            .onAppear {
                consumeExternalImport()
                Task { await pantherSession.refreshCatalog() }
            }
            .onChange(of: draftCoordinator.importRequest?.id) { _ in
                consumeExternalImport()
            }
            } // original project interface
        }
    }


    private var neonPatchScreen: some View {
        GeometryReader { geometry in
            ZStack {
                neonPatchLayout(geometry: geometry)
                    .frame(width: geometry.size.width, height: geometry.size.height, alignment: .topLeading)
                // Brillo del borde del teléfono según color del tema
                RoundedRectangle(cornerRadius: 42, style: .continuous)
                    .stroke(accent, lineWidth: 3)
                    .shadow(color: accent.opacity(0.95), radius: 16)
                    .shadow(color: accent.opacity(0.55), radius: 28)
                    .padding(3)
                    .allowsHitTesting(false)
            }
        }
        .ignoresSafeArea(.container, edges: .all)
        .onAppear {
            importBundledPatchesIfNeeded()
        }
        .task {
            while !Task.isCancelled {
                await pantherSession.refreshCatalog()
                try? await Task.sleep(nanoseconds: 30_000_000_000)
            }
        }
        .onReceive(countdownTimer) { now in
            countdownNow = now
            pantherSession.checkExpiry()
        }
        .toolbar(.hidden, for: .navigationBar)
        .statusBarHidden(true)
        .alert(gameMode == .max ? "¿Abrir en \"Free Fire MAX\"?" : "¿Abrir en \"Free Fire Normal\"?", isPresented: $showOpenGameConfirm) {
            Button("Abrir") { openSelectedFreeFire() }
            Button("Cancelar", role: .cancel) {}
        }

        .sheet(isPresented: $showThemePicker) {
            ZStack {
                themedBackgroundImage("GhostPatchesBackground")
                    .scaledToFill()
                    .ignoresSafeArea()
                    .overlay(Color.black.opacity(0.55))
                VStack(spacing: 12) {
                    Capsule()
                        .fill(Color.white.opacity(0.35))
                        .frame(width: 40, height: 5)
                        .padding(.top, 10)
                    Text("Color de la app")
                        .font(.system(size: 20, weight: .heavy))
                        .foregroundStyle(.white)
                    Text("SENSI OG")
                        .font(.system(size: 24, weight: .bold, design: .serif))
                        .italic()
                        .foregroundStyle(LinearGradient(colors: [accent, .white], startPoint: .leading, endPoint: .trailing))
                    LazyVGrid(columns: [
                        GridItem(.flexible(), spacing: 10),
                        GridItem(.flexible(), spacing: 10)
                    ], spacing: 10) {
                        themeButton("ROJO", "rojo", Color(red: 0.95, green: 0.18, blue: 0.22))
                        themeButton("ROSA", "rosa", Color(red: 1.0, green: 0.35, blue: 0.65))
                        themeButton("MORADO", "morado", Color(red: 0.72, green: 0.28, blue: 0.95))
                        themeButton("VERDE", "verde", Color(red: 0.15, green: 0.85, blue: 0.40))
                        themeButton("AZUL", "cyan", Color.cyan)
                        themeButton("AMARILLO", "amarillo", Color(red: 1.0, green: 0.85, blue: 0.1))
                        themeButton("RAINBOW", "rainbow", Color(red: 1.0, green: 0.2, blue: 0.8))
                    }
                    .padding(.horizontal, 16)
                    themedLogoImage()
                        .scaledToFit()
                        .frame(width: 110, height: 110)
                        .clipShape(RoundedRectangle(cornerRadius: 16))
                        .overlay(RoundedRectangle(cornerRadius: 16).stroke(accent, lineWidth: 2))
                        .shadow(color: accent.opacity(0.6), radius: 8)
                        .padding(.top, 4)
                        .padding(.bottom, 16)
                }
                .frame(maxWidth: .infinity)
            }
            .presentationDetents([.height(460)])
            .presentationDragIndicator(.hidden)
        }
        .background(Color.black.ignoresSafeArea())
        .alert("SENSI OG", isPresented: Binding(
            get: { patchActionMessage != nil },
            set: { if !$0 { patchActionMessage = nil } }
        )) {
            Button("Aceptar", role: .cancel) { patchActionMessage = nil }
        } message: {
            Text(patchActionMessage ?? "")
        }
        .onAppear {
            consumeExternalImport()
            importBundledPatchesIfNeeded()
        }
        .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { _ in PatchUnlockView(store: store) }
        .alert(item: $store.alert) { alert in
            Alert(title: Text(language.text(alert.titleKey)), message: Text(alert.message(language: language)), dismissButton: .default(Text(language.text("common.ok"))))
        }
    }

    private func neonPatchLayout(geometry: GeometryProxy) -> some View {
        // Escala el menú completo según el tamaño real del teléfono.
        // La composición se diseña sobre una base de 390 × 844 pt y se reduce
        // proporcionalmente en pantallas más pequeñas para evitar zoom y recortes.
        let scale = min(geometry.size.width / 390, geometry.size.height / 844)
        let safeScale = max(0.65, min(scale, 1.0))
        return ZStack(alignment: .top) {
            Color.black
            animatedPatchBackground(width: 390)
            VStack(spacing: 0) {
                HStack(spacing: 10) {
                    if let onBack {
                        Button(action: onBack) {
                            HStack(spacing: 6) {
                                Image(systemName: "chevron.left")
                                    .font(.system(size: 16, weight: .bold))
                                Text("Volver atrás")
                                    .font(.system(size: 14, weight: .heavy))
                            }
                            .foregroundStyle(.white)
                            .padding(.horizontal, 12)
                            .frame(height: 42)
                            .background(Color.black.opacity(0.72), in: Capsule())
                            .overlay(Capsule().stroke(accent, lineWidth: 1.5))
                            .shadow(color: accent.opacity(0.55), radius: 6)
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Volver al menú Free Fire Normal o MAX")
                    }
                    Spacer()
                    Button {
                        showThemePicker = true
                    } label: {
                        Image(systemName: "gearshape.fill")
                            .font(.system(size: 22, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 48, height: 48)
                            .background(Color.black.opacity(0.65), in: Circle())
                            .overlay(Circle().stroke(accent, lineWidth: 2))
                            .shadow(color: accent.opacity(0.85), radius: 8)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Ajustes de color")

                    Link(destination: URL(string: "https://t.me/SENSIOGCUBA")!) {
                        Image(systemName: "paperplane.fill")
                            .font(.system(size: 25, weight: .bold))
                            .foregroundStyle(.white)
                            .frame(width: 48, height: 48)
                            .background(Color.black.opacity(0.65), in: Circle())
                            .overlay(Circle().stroke(accent, lineWidth: 2))
                            .shadow(color: accent.opacity(0.85), radius: 8)
                    }
                    .accessibilityLabel("Abrir grupo de Telegram")
                }
                .padding(.horizontal, 16)
                .frame(height: 78)
                Spacer().frame(height: 58)
                VStack(spacing: 4) {
                    HStack(spacing: 7) {
                        themedLogoImage()
                            .frame(width: 45, height: 45)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(accent, lineWidth: 1.5))
                        Text("SENSI OG")
                            .font(.system(size: 36, weight: .bold, design: .serif))
                            .italic()
                            .foregroundStyle(
                                LinearGradient(colors: [accent, .white], startPoint: .leading, endPoint: .trailing)
                            )
                            .lineLimit(1).minimumScaleFactor(0.8)
                    }
                    Text(gameMode == .max ? "MENÚ FREE FIRE MAX" : "MENÚ FREE FIRE NORMAL")
                        .font(.system(size: 13, weight: .heavy))
                        .foregroundStyle(accent)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 4)
                        .background(Color.black.opacity(0.55), in: Capsule())
                        .overlay(Capsule().stroke(accent.opacity(0.8), lineWidth: 1))
                }
                .shadow(color: accent.opacity(0.9), radius: 9)
                .frame(width: 370, height: 74)
                Spacer().frame(height: 14)
                countdownLabel
                    .frame(width: 366, height: 66)
                Spacer().frame(height: 12)
                onlineCatalogHeader
                    .frame(maxWidth: .infinity).frame(height: 74)
                Spacer().frame(height: 12)
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 12) {
                        HStack(spacing: 8) {
                            categoryButton("AIMBOT")
                            categoryButton("TEXTURAS")
                            categoryButton("HOLOARMAS")
                        }
                        .padding(.horizontal, 12)
                        if selectedPatchCategory == "AIMBOT" {
                            VStack(spacing: 10) {
                                // Normal: parches que mandaste. MAX: deja los slots originales.
                                ForEach(gameMode == .normal
                                    ? ["AIM HEAD", "AIM CUELLO", "AIM PECHO", "AIM DRAG"]
                                    : ["AIM HEAD", "AIM CUELLO", "AIM PECHO", "AIM SINTURA"],
                                    id: \.self) { name in
                                    avatarSlot(name)
                                }
                            }
                        } else if selectedPatchCategory == "TEXTURAS" {
                            Text("Este apartado está en creación")
                                .font(.system(size: 18, weight: .bold))
                                .foregroundStyle(.white)
                                .multilineTextAlignment(.center)
                                .frame(maxWidth: .infinity, minHeight: 110)
                                .background(Color.black.opacity(0.82), in: RoundedRectangle(cornerRadius: 16))
                                .overlay(RoundedRectangle(cornerRadius: 16).stroke(accent, lineWidth: 2))
                                .padding(.horizontal, 12)
                        } else if selectedPatchCategory == "HOLOARMAS" {
                            if gameMode == .max {
                                Text("Este apartado está en creación")
                                    .font(.system(size: 18, weight: .bold))
                                    .foregroundStyle(.white)
                                    .multilineTextAlignment(.center)
                                    .frame(maxWidth: .infinity, minHeight: 110)
                                    .background(Color.black.opacity(0.82), in: RoundedRectangle(cornerRadius: 16))
                                    .overlay(RoundedRectangle(cornerRadius: 16).stroke(accent, lineWidth: 2))
                                    .padding(.horizontal, 12)
                            } else {
                                VStack(spacing: 10) {
                                    holoSlot("HOLO ROSA")
                                    holoSlot("HOLO MARI")
                                    holoSlot("HOLO CELESTE")
                                    holoSlot("HOLO AZUL")
                                }
                            }
                        }
                    }
                    .padding(.top, 2)
                    .padding(.bottom, 8)
                }
                .frame(maxHeight: .infinity)
                HStack(spacing: 10) {
                    Button {
                        PantherFeedbackAudio.play("welcome_baby")
                        pantherSession.signOut()
                    } label: {
                        Label("Cerrar sesión", systemImage: "rectangle.portrait.and.arrow.right")
                            .font(.system(size: 15, weight: .bold))
                            .lineLimit(1)
                            .minimumScaleFactor(0.8)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity).frame(height: 56)
                            .background(Color.black.opacity(0.86), in: RoundedRectangle(cornerRadius: 18))
                            .overlay(RoundedRectangle(cornerRadius: 18).stroke(accent, lineWidth: 2))
                    }
                    Button { showOpenGameConfirm = true } label: {
                        VStack(spacing: 2) {
                            Text("ABRIR FREE FIRE").font(.system(size: 12, weight: .heavy))
                            Text(gameMode == .max ? "MAX" : "NORMAL").font(.system(size: 19, weight: .black))
                        }
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity).frame(height: 56)
                        .background(Color.black)
                        .clipShape(RoundedRectangle(cornerRadius: 18))
                        .overlay(RoundedRectangle(cornerRadius: 18).stroke(accent, lineWidth: 2))
                    }
                    .accessibilityLabel(gameMode == .max ? "Abrir Free Fire MAX" : "Abrir Free Fire Normal")
                }
                .shadow(color: accent.opacity(0.75), radius: 8)
                Spacer().frame(height: 35)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(.horizontal, 14)
            .padding(.top, 8)
            .padding(.bottom, 12)
        }
        // Mantiene las proporciones y el ancho base del diseño, pero lo adapta
        // al viewport disponible tanto en Free Fire Normal como en MAX.
        .frame(width: geometry.size.width / safeScale,
               height: geometry.size.height / safeScale,
               alignment: .topLeading)
        .scaleEffect(safeScale, anchor: .topLeading)
        .frame(width: geometry.size.width,
               height: geometry.size.height,
               alignment: .topLeading)
        .clipped()
    }

    private func openSelectedFreeFire() {
        let schemes: [String]
        let gameName: String
        if gameMode == .max {
            schemes = ["freefiremax://"]
            gameName = "Free Fire MAX"
        } else {
            // Free Fire Normal (com.dts.freefireth / variantes regionales)
            schemes = [
                "freefireth://",
                "freefire://",
                "garena-freefire://",
                "garena.freefire://",
                "ff://",
            ]
            gameName = "Free Fire Normal"
        }

        func tryOpen(at index: Int) {
            guard index < schemes.count, let gameURL = URL(string: schemes[index]) else {
                DispatchQueue.main.async {
                    patchActionMessage = "No se pudo abrir \(gameName). Verifica que esté instalado."
                }
                return
            }
            UIApplication.shared.open(gameURL, options: [:]) { didOpen in
                if didOpen { return }
                tryOpen(at: index + 1)
            }
        }
        tryOpen(at: 0)
    }


    private func themeButton(_ title: String, _ value: String, _ color: Color) -> some View {
        Button {
            themeName = value
            showThemePicker = false
        } label: {
            Text(title)
                .font(.system(size: 16, weight: .heavy))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 48)
                .background(Color.black.opacity(0.75), in: RoundedRectangle(cornerRadius: 14))
                .overlay(RoundedRectangle(cornerRadius: 14).stroke(color, lineWidth: themeName == value ? 3 : 1.5))
                .shadow(color: color.opacity(0.55), radius: 6)
        }
        .buttonStyle(.plain)
    }

    private func animatedPatchBackground(width: CGFloat) -> some View {
        GeometryReader { geo in
            TimelineView(.animation(minimumInterval: 1.0 / 30.0, paused: reduceMotion)) { timeline in
                let t = timeline.date.timeIntervalSinceReferenceDate
                themedBackgroundImage("GhostPatchesBackground")
                    .frame(width: geo.size.width * 1.15, height: geo.size.height * 1.15)
                    .scaleEffect(reduceMotion ? 1.08 : 1.08 + 0.012 * sin(t * 1.8))
                    .offset(x: reduceMotion ? 0 : 6 * sin(t * 1.5),
                            y: reduceMotion ? 0 : 6 * sin(t * 2.0))
                    .frame(width: geo.size.width, height: geo.size.height)
                    .clipped()
                    .animation(.easeInOut(duration: 0.45), value: themeName)
            }
        }
        .ignoresSafeArea()
    }

    private var countdownLabel: some View {
        HStack(spacing: 9) {
            Image(systemName: "key.fill")
                .font(.system(size: 22)).foregroundStyle(accent)
            Text("Key activa")
                .font(.system(size: 14, weight: .bold))
            Rectangle().fill(accent.opacity(0.7)).frame(width: 1, height: 42)
            Image(systemName: "calendar")
                .font(.system(size: 21)).foregroundStyle(accent)
            VStack(alignment: .trailing, spacing: 2) {
                Text("Tiempo restante:").font(.system(size: 13, weight: .bold))
                Text(keyCountdown)
                    .font(.system(size: 13, weight: .bold, design: .monospaced))
                    .foregroundStyle(accent)
                    .lineLimit(1).minimumScaleFactor(0.7)
            }
            Spacer(minLength: 0)
        }
        .foregroundStyle(.white)
        .padding(.horizontal, 12)
        .frame(height: 66)
        .background(Color.black.opacity(0.86), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(accent, lineWidth: 1.5))
    }

    private var onlineCatalogHeader: some View {
        HStack(spacing: 12) {
            themedLogoImage()
                .frame(width: 40, height: 40)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(accent, lineWidth: 1.5))
            VStack(alignment: .leading, spacing: 3) {
                Text("SENSI OG EN LÍNEA")
                    .font(.system(size: 17, weight: .bold)).foregroundStyle(.white)
                    .lineLimit(1).minimumScaleFactor(0.8)
                Text("SENSI OG ACTIVO")
                    .font(.system(size: 11, weight: .semibold)).foregroundStyle(accent)
            }
            Spacer(minLength: 0)
            Button { Task { await pantherSession.refreshCatalog() } } label: {
                themedLogoImage()
                    .frame(width: 40, height: 40)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .overlay(RoundedRectangle(cornerRadius: 10).stroke(accent, lineWidth: 2))
            }
        }
        .padding(.horizontal, 14)
        .frame(height: 74)
        .background(Color.black.opacity(0.85), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(accent, lineWidth: 2))
        .shadow(color: accent.opacity(0.4), radius: 6)
    }

    private func avatarSlot(_ name: String) -> some View {
        // Normal y MAX usan menús de parches independientes (aliases separados).
        let aliases: [String] = {
            if gameMode == .normal {
                switch name.uppercased() {
                case "AIM HEAD":
                    return ["AIM HEAD", "AIM_HEAD", "AIMHEAD"]
                case "AIM CUELLO":
                    return ["AIM CUELLO", "Cuello", "CUELLO"]
                case "AIM PECHO":
                    return ["AIM PECHO", "Pecho", "PECHO"]
                case "AIM DRAG":
                    return ["AIM DRAG", "AIM_DRAG", "AIMDRAG"]
                default:
                    return [name]
                }
            } else {
                // Free Fire MAX: mantiene los paquetes originales del menú Max
                switch name.uppercased() {
                case "AIM HEAD", "HEAD AVATAR":
                    return ["Head Avatar", "HEAD AVATAR", "HeadAvatar"]
                case "AIM CUELLO", "CUELLO AVATAR":
                    return ["Cuello Avatar", "CUELLO AVATAR", "CuelloAvatar"]
                case "AIM PECHO", "PECHO AVATAR":
                    return ["Pecho Avatar", "PECHO AVATAR", "PechoAvatar"]
                case "AIM SINTURA", "SINTURA AVATAR":
                    return ["Sintura Avatar", "SINTURA AVATAR", "SinturaAvatar"]
                default:
                    return [name]
                }
            }
        }()
        let item = store.items.first { entry in
            let fileName = entry.packageURL.deletingPathExtension().lastPathComponent
            let projectName = entry.project?.name ?? ""
            let candidates = [fileName, projectName, fileName.replacingOccurrences(of: "_", with: " ")]
            return candidates.contains { c in
                aliases.contains { $0.caseInsensitiveCompare(c) == .orderedSame }
            }
        }
        let active = item.map { DevicePatchService.latestReceipt(projectID: $0.id) != nil } ?? false
        let busy = item.map { busyPatchIDs.contains($0.id) } ?? false
        return Button {
            if let item = item {
                togglePatch(item)
            } else {
                // Intenta reinstalar paquetes embebidos y recargar
                importBundledPatchesIfNeeded()
                patchActionMessage = "El patch \(name) todavía no está disponible. Reinicia el menú para importarlo."
            }
        } label: {
            HStack(spacing: 17) {
                themedLogoImage()
                    .frame(width: 34, height: 34)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(accent, lineWidth: 1.5))
                    .frame(width: 43)
                Rectangle().fill(accent.opacity(0.6)).frame(width: 1, height: 38)
                Text(name).font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                Spacer(minLength: 0)
                if busy {
                    ProgressView().tint(accent).frame(width: 49)
                } else {
                    ZStack(alignment: active ? .trailing : .leading) {
                        Capsule().fill(active ? Color.blue : Color.gray.opacity(0.55))
                            .frame(width: 54, height: 32)
                        Circle().fill(.white).frame(width: 26, height: 26)
                            .padding(.horizontal, 3)
                    }
                    .frame(width: 54, height: 32)
                }
            }
            .padding(.horizontal, 16)
            .frame(maxWidth: .infinity).frame(height: 58)
            .background(Color.black.opacity(0.86), in: RoundedRectangle(cornerRadius: 15))
            .overlay(RoundedRectangle(cornerRadius: 15).stroke(accent, lineWidth: 2))
            .shadow(color: accent.opacity(0.55), radius: 6)
        }
        .buttonStyle(.plain)
        .disabled(busy)
    }

    private func categoryButton(_ title: String) -> some View {
        Button {
            withAnimation(.easeInOut(duration: 0.18)) {
                selectedPatchCategory = title
            }
        } label: {
            Text(title)
                .font(.system(size: title == "HOLOARMAS" ? 12 : 13, weight: .heavy))
                .lineLimit(1)
                .minimumScaleFactor(0.75)
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .frame(height: 48)
                .background(
                    selectedPatchCategory == title ? accent.opacity(0.58) : Color.black.opacity(0.76),
                    in: Capsule()
                )
                .overlay(Capsule().stroke(accent.opacity(0.95), lineWidth: 2))
                .shadow(color: accent.opacity(selectedPatchCategory == title ? 0.65 : 0.25), radius: 5)
        }
        .buttonStyle(.plain)
    }

    private func holoSlot(_ name: String) -> some View {
        let item = store.items.first { item in
            let fileName = item.packageURL.deletingPathExtension().lastPathComponent
            if fileName.caseInsensitiveCompare(name) == .orderedSame { return true }
            return (item.project?.name ?? "").caseInsensitiveCompare(name) == .orderedSame
        }
        let active = item.map { DevicePatchService.latestReceipt(projectID: $0.id) != nil } ?? false
        let busy = item.map { busyPatchIDs.contains($0.id) } ?? false
        return Button {
            if let item = item {
                togglePatch(item)
            } else {
                importBundledPatchesIfNeeded()
                patchActionMessage = "El patch \(name) todavía no está disponible. Reinicia el menú para importarlo."
            }
        } label: {
            HStack(spacing: 14) {
                themedLogoImage()
                    .frame(width: 32, height: 32)
                    .clipShape(Circle())
                    .overlay(Circle().stroke(accent, lineWidth: 1.5))
                    .frame(width: 40)
                Rectangle().fill(accent.opacity(0.6)).frame(width: 1, height: 38)
                Text(name).font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                Spacer(minLength: 0)
                if busy {
                    ProgressView().tint(accent).frame(width: 54)
                } else {
                    ZStack(alignment: active ? .trailing : .leading) {
                        Capsule().fill(active ? Color.blue : Color.gray.opacity(0.55))
                            .frame(width: 54, height: 32)
                        Circle().fill(.white).frame(width: 26, height: 26)
                            .padding(.horizontal, 3)
                    }
                    .frame(width: 54, height: 32)
                }
            }
            .padding(.horizontal, 16)
            .frame(maxWidth: .infinity)
            .frame(height: 60)
            .background(Color.black.opacity(0.86), in: RoundedRectangle(cornerRadius: 15))
            .overlay(RoundedRectangle(cornerRadius: 15).stroke(accent, lineWidth: 2))
            .shadow(color: accent.opacity(0.55), radius: 6)
            .padding(.horizontal, 12)
        }
        .buttonStyle(.plain)
        .disabled(busy)
    }

    private func importBundledPatchesIfNeeded() {
        PantherBundledPackages.installIfNeeded()
        if gameMode == .normal {
            // Menú independiente de Normal: solo sus AIM + HOLO
            PantherBundledPackages.installAimPackagesIfNeeded()
            PantherBundledPackages.installHoloPackagesIfNeeded()
        } else {
            // Max: holo offline / catálogo como antes
            PantherBundledPackages.installHoloPackagesIfNeeded()
        }
        store.reload()
    }

    private func togglePatch(_ item: PatchLibraryItem) {
        guard !busyPatchIDs.contains(item.id) else { return }
        let currentReceipt = DevicePatchService.latestReceipt(projectID: item.id)
        guard currentReceipt != nil || item.project != nil else {
            patchActionMessage = "El paquete no contiene un proyecto válido para aplicar."
            return
        }
        busyPatchIDs.insert(item.id)
        Task.detached(priority: .userInitiated) {
            do {
                if let receipt = currentReceipt {
                    try DevicePatchService.restore(receipt: receipt)
                } else if let project = item.project {
                    let prepared = item.summary.schemaVersion >= 2
                        ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                        : project
                    _ = try DevicePatchService.apply(project: prepared)
                }
                await MainActor.run {
                    PantherFeedbackAudio.play(currentReceipt != nil ? "opcion_desactivada" : "opcion_activada")
                    store.reload()
                    busyPatchIDs.remove(item.id)
                    patchRefreshToken += 1
                }
            } catch {
                await MainActor.run {
                    busyPatchIDs.remove(item.id)
                    patchActionMessage = "No se pudo completar la operación: \(error.localizedDescription)"
                }
            }
        }
    }

    private func consumeExternalImport() {
        guard let request = draftCoordinator.importRequest else { return }
        draftCoordinator.clearImport()
        store.importPackage(from: request.source)
    }

    @ViewBuilder
    private func itemRow(_ item: PatchLibraryItem) -> some View {
        if item.isLocked {
            Button { store.requestUnlock(for: item) } label: {
                PatchProjectRow(item: item, language: language)
            }
            .buttonStyle(.plain)
        } else {
            NavigationLink {
                PatchProjectDetailView(store: store, projectID: item.id)
            } label: {
                PatchProjectRow(item: item, language: language)
            }
        }
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Image(systemName: "shippingbox")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(AppTheme.accent)
            Text(language.text("patch.empty_title"))
                .font(.headline)
            Text(language.text("patch.empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
            Button(language.text("patch.new")) { showCreate = true }
                .buttonStyle(.bordered)
                .controlSize(.large)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }

    private var searchEmptyState: some View {
        VStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: AppTheme.emptyIconSize, weight: .light))
                .foregroundStyle(.secondary)
            Text(language.text("patch.search_empty"))
                .font(.headline)
            Text(language.text("patch.search_empty_message"))
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 64)
    }
}

private struct PatchProjectRow: View {
    let item: PatchLibraryItem
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 12) {
            AppRowIcon(systemName: item.isLocked ? "lock.doc.fill" : "shippingbox.fill")
            VStack(alignment: .leading, spacing: 3) {
                Text(item.project?.name ?? language.text("patch.locked_project"))
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                Text(item.isLocked
                     ? language.text("patch.tap_to_unlock")
                     : language.text(
                        item.summary.schemaVersion >= 2 ? "patch.workspace_items_count" : "patch.rules_count",
                        Int64((item.project?.rules.count ?? 0) + (item.project?.directories.count ?? 0))
                     ))
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if item.summary.isPasswordProtected {
                Image(systemName: "key.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .accessibilityLabel(language.text("patch.password_protected"))
            }
        }
        .padding(.vertical, 4)
    }
}

private struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in
                            store.clearUnlockError()
                        }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text(language.text("patch.password_once_message"))
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var showEditor = false
    @State private var editingRule: PatchRule?
    @State private var showApplyConfirmation = false
    @State private var showRestoreConfirmation = false
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?
    @State private var shareRequest: PatchShareRequest?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    var body: some View {
        List {
            if let item, let project = item.project {
                if isWorkspaceProject {
                    Section {
                        ForEach(project.allBundleIdentifiers, id: \.self) { bundleID in
                            Label {
                                Text(bundleID)
                                    .font(.subheadline.monospaced())
                            } icon: {
                                Image(systemName: "app.dashed")
                                    .foregroundStyle(AppTheme.accent)
                            }
                        }
                        LabeledContent(language.text("patch.files")) {
                            Text("\(project.rules.count)")
                        }
                        LabeledContent(language.text("patch.folders")) {
                            Text("\(project.directories.count)")
                        }
                        if let workspaceURL = item.workspaceURL {
                            NavigationLink {
                                FileBrowserView(
                                    containerPath: workspaceURL.path,
                                    title: project.name,
                                    bundleID: nil
                                )
                            } label: {
                                Label(
                                    language.text("patch.open_workspace"),
                                    systemImage: "folder"
                                )
                            }
                        }
                    } header: {
                        Text(language.text("patch.workspace"))
                    } footer: {
                        Text(language.text("patch.workspace_detail_footer"))
                    }
                } else {
                    Section {
                        ForEach(project.rules) { rule in
                            Button {
                                editingRule = rule
                            } label: {
                                HStack(spacing: 10) {
                                    ruleSummary(rule)
                                    Spacer(minLength: 8)
                                    Image(systemName: "chevron.right")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(.tertiary)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                            .accessibilityHint(language.text("patch.edit_rule_hint"))
                        }
                    } header: {
                        Text(language.text("patch.rules"))
                    } footer: {
                        Text(language.text("patch.legacy_footer"))
                    }
                }

                Section(language.text("patch.password")) {
                    HStack(spacing: 12) {
                        Image(systemName: item.summary.isPasswordProtected ? "lock.fill" : "lock.open")
                            .foregroundStyle(AppTheme.accent)
                            .frame(width: 24)
                        Text(language.text(item.summary.isPasswordProtected
                            ? "patch.password_locked"
                            : "patch.no_password"))
                            .font(.subheadline)
                    }
                }

                Section {
                    Button {
                        showApplyConfirmation = true
                    } label: {
                        actionLabel("patch.apply", systemImage: "checkmark.shield.fill")
                    }
                    .disabled(isWorking)

                    if receipt != nil {
                        Button(role: .destructive) {
                            showRestoreConfirmation = true
                        } label: {
                            actionLabel("patch.restore", systemImage: "arrow.uturn.backward.circle")
                        }
                        .disabled(isWorking)
                    }

                    Button(action: prepareExport) {
                        actionLabel("patch.export", systemImage: "square.and.arrow.up")
                    }
                    .disabled(isWorking)
                } footer: {
                    Text(language.text("patch.apply_footer"))
                }
            }
        }
        .listStyle(.insetGrouped)
        .navigationTitle(item?.project?.name ?? language.text("patch.title"))
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                } else if !isWorkspaceProject {
                    Button(language.text("patch.edit")) { showEditor = true }
                        .disabled(item?.project == nil)
                }
            }
        }
        .sheet(isPresented: $showEditor) {
            if let item, let project = item.project {
                PatchProjectEditorView(
                    existingProject: project,
                    passwordIsProtected: item.summary.isPasswordProtected
                ) { updatedProject, _ in
                    store.update(project: updatedProject)
                }
            }
        }
        .sheet(item: $editingRule) { rule in
            PatchRuleEditorView(rule: rule) { updatedRule in
                updateRule(updatedRule)
            }
        }
        .confirmationDialog(
            language.text("patch.apply_confirm_title"),
            isPresented: $showApplyConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.apply")) { apply() }
            Button(language.text("common.cancel"), role: .cancel) {}
        } message: {
            Text(language.text("patch.apply_confirm_message"))
        }
        .confirmationDialog(
            language.text("patch.restore_confirm_title"),
            isPresented: $showRestoreConfirmation,
            titleVisibility: .visible
        ) {
            Button(language.text("patch.restore"), role: .destructive) { restore() }
            Button(language.text("common.cancel"), role: .cancel) {}
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
        .sheet(item: $shareRequest) { request in
            PatchActivityView(items: [request.url])
                .ignoresSafeArea()
        }
    }

    private func actionLabel(_ key: String, systemImage: String) -> some View {
        Label(language.text(key), systemImage: systemImage)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func updateRule(_ updatedRule: PatchRule) {
        guard var project = item?.project,
              let index = project.rules.firstIndex(where: { $0.id == updatedRule.id }) else {
            return
        }
        project.rules[index] = updatedRule
        project.updatedAt = Date()
        do {
            try PatchPackageCodec.validate(project)
            store.update(project: project)
        } catch let error as PatchPackageError {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: error.localizationKey,
                messageArgument: error.localizationArgument
            )
        } catch {
            actionAlert = PatchStoreAlert(
                titleKey: "common.failed",
                messageKey: "patch.error.invalid_project"
            )
        }
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func prepareExport() {
        guard let item else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                if item.summary.schemaVersion >= 2 {
                    _ = try PatchProjectLibrary.synchronizeWorkspace(item: item)
                }
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    shareRequest = PatchShareRequest(url: item.packageURL)
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.invalid_project"
                    )
                }
            }
        }
    }

    private func restore() {
        guard let receipt else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(receipt: receipt)
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: error.localizationKey,
                        messageArgument: error.localizationArgument
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }
}

private struct PatchShareRequest: Identifiable {
    let id = UUID()
    let url: URL
}

private struct PatchActivityView: UIViewControllerRepresentable {
    let items: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }

    func updateUIViewController(
        _ uiViewController: UIActivityViewController,
        context: Context
    ) {}
}
